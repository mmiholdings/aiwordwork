def generate_natal_profile(info):
    # Placeholder - should use Flatlib or other tool
    return {"sun_sign": "Cancer", "moon_sign": "Pisces", "rising": "Libra"}
